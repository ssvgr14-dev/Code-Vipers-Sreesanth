import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Leaf, Globe, ChevronDown, Menu, X } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/translations';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { useState } from 'react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { state, dispatch } = useApp();
  const { language, role, cart } = state;
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const cartCount = cart.reduce((s, i) => s + i.quantity, 0);

  const navLinks = [
    { to: '/', label: t('nav.home', language) },
    { to: '/marketplace', label: t('nav.marketplace', language) },
    ...(role === 'farmer' ? [{ to: '/farmer', label: t('nav.dashboard', language) }] : []),
    ...(role === 'admin' ? [{ to: '/admin', label: t('nav.admin', language) }] : []),
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-card/80 backdrop-blur-md">
        <div className="container mx-auto flex items-center justify-between h-16 px-4">
          <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold text-primary">
            <Leaf className="h-6 w-6" />
            AgriDirect
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map(l => (
              <Link
                key={l.to}
                to={l.to}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  location.pathname === l.to ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {/* Language Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => dispatch({ type: 'SET_LANGUAGE', language: language === 'en' ? 'ta' : 'en' })}
              className="gap-1 text-muted-foreground"
            >
              <Globe className="h-4 w-4" />
              <span className="hidden sm:inline">{t('general.language', language)}</span>
            </Button>

            {/* Role Switcher (demo) */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-1 capitalize">
                  {t(`general.${role}`, language)}
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                {(['consumer', 'farmer', 'admin'] as const).map(r => (
                  <DropdownMenuItem key={r} onClick={() => dispatch({ type: 'SET_ROLE', role: r })}>
                    {t(`general.${r}`, language)}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Cart */}
            {role === 'consumer' && (
              <Link to="/checkout" className="relative">
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
                  <ShoppingCart className="h-5 w-5" />
                  {cartCount > 0 && (
                    <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-accent text-accent-foreground border-0">
                      {cartCount}
                    </Badge>
                  )}
                </Button>
              </Link>
            )}

            {/* Mobile menu */}
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <nav className="md:hidden border-t border-border bg-card px-4 py-3 space-y-2">
            {navLinks.map(l => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setMobileOpen(false)}
                className={`block py-2 text-sm font-medium ${
                  location.pathname === l.to ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                {l.label}
              </Link>
            ))}
          </nav>
        )}
      </header>

      <main className="flex-1">{children}</main>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Leaf className="h-4 w-4 text-primary" />
            <span className="font-display font-semibold text-foreground">AgriDirect</span>
          </div>
          <p>© 2026 AgriDirect. Farm-to-Consumer Direct Marketplace.</p>
        </div>
      </footer>
    </div>
  );
}
